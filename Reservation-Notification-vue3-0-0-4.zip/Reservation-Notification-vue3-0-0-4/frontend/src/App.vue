<script setup>
import Default from '@/layouts/default.vue'
import ReservationNotification from './components/ReservationNotification.vue'
</script>

<template>
  <VApp>
    <Default style="display: none;" />
    <ReservationNotification />
  </VApp>
</template>
